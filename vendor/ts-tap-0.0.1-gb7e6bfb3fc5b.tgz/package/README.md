# ts-tap

A TypeScript implementation of the [Taproot Assets Protocol](https://github.com/lightninglabs/taproot-assets)
(TAP), modelled on [rust-tap](https://github.com/coreyphillips/rust-tap) and
built to be consumed by [beignet](https://github.com/coreyphillips/beignet).

> **Not ready for mainnet.** ts-tap implements on-chain minting, sending,
> receiving, burning, proof import/export and proof delivery. The Beignet
> adapter and isolated regtest examples exercise these operations with real
> Bitcoin transactions. This is experimental protocol software; do not use
> it to hold or move real assets.
>
> Proofs are built, stored and delivered once the anchor transaction has
> `minConfirmations` confirmations (1 on regtest, 6 elsewhere). A reorg
> after that is repaired only when the host calls `repairProofs()` on the
> minter and freighter, for example on each new block. The Beignet
> adapter trusts its Electrum server for the best chain; see
> [chain trust](docs/beignet.md#chain-trust).

## Beignet quickstart

The unpublished library and adapter are consumed together through this
repository's npm workspace, or as [release tarballs](#release-tarballs) by a
host outside it. Node `^22.23.4 || ^24.22.1 || >=26.12.1` and
Docker Compose are required for the live examples.

```sh
npm ci
npm run build:all
npm run regtest
```

`regtest` starts an isolated Bitcoin Core, Electrum, lnd and pinned tapd
stack, creates regtest coins, and runs the seven examples and tapd
interoperability checks. It fails if an assertion fails. It leaves the stack
running; `npm run regtest:stop` stops it without deleting its volumes.
The tapd image includes a small mailbox WebSocket routing fix, documented
in the walkthrough; protocol rules and the test-vector pin are unchanged.
Stock tapd lacks that fix, so receiving to a V2 address only works through a
courier running the patched tapd ([#46](https://github.com/coreyphillips/ts-tap/issues/46)).

```ts
import { asset } from 'ts-tap';
import { createBeignetAdapter } from '@ts-tap/beignet';

// wallet is a connected, funded Beignet Wallet. stores and keyIndexes are
// the host's durable FreighterStores and KeyIndexStore for this wallet.
const tap = createBeignetAdapter(wallet, { stores, keyIndexes });
await tap.minter.queue({
  name: 'Credits',
  type: asset.AssetType.Normal,
  amount: 1000n
});
const batch = await tap.minter.finalize({ feeRate: 1 });
// On regtest, mine a block before waiting.
await tap.minter.waitForConfirmation(batch.batchId);
console.log(await tap.freighter.listBalances());
```

Every `feeRate` in ts-tap is in sat/vB. tapd's RPC `fee_rate` fields are in
sat/kw, and 1 sat/vB is 250 sat/kw, so divide a rate taken from tapd by 250.
`finalize`, `send` and `burn` refuse a rate that is not finite and above
zero. Each also takes `maxFee`, the most sats that one transaction may pay,
and throws `ERR_WALLET_FEE_ABOVE_LIMIT` before signing when funding would
cost more. The Beignet adapter also refuses rates and fees above its limits;
see [fees](docs/beignet.md#fees), which also shows how to stop a mint or send
after funding to [show its fee](docs/beignet.md#showing-the-fee-before-paying-it)
before anything is broadcast.

Pass the same `stores` and `keyIndexes` every time the adapter is rebuilt.
Parcel and batch ids are derived keys, so the adapter throws if `stores` is
given without `keyIndexes`. `createBeignetAdapter(wallet)` with no options
keeps everything in memory and is only for throwaway use: after a restart it
has forgotten its assets and hands out keys it has already used.

The adapter takes its network and address prefix from `wallet.network`.
Beignet's `testnet` is testnet3 or testnet4, so a testnet wallet must pass
`tapNetwork: 'testnet3'` or `tapNetwork: 'testnet4'`, and the adapter throws
`ERR_BEIGNET_NETWORK` without it. See [networks](docs/beignet.md#networks).

For sends and receives, configure a courier as shown in
[`examples/helpers.ts`](examples/helpers.ts). A courier URI names tapd's gRPC
port, so the application must map it to a REST endpoint; see
[courier endpoints](docs/beignet.md#courier-endpoints-grpc-versus-rest).
To receive an asset the wallet has never held, `freighter.lookupAsset`
fetches and verifies its issuance from a universe by asset ID or group key
and returns the genesis an address needs; see
[receiving an asset the wallet has never held](docs/beignet.md#receiving-an-asset-the-wallet-has-never-held).
The complete workflows are in
[`examples/run.ts`](examples/run.ts), with the integration and persistence
contract in the [Beignet walkthrough](docs/beignet.md).

## Status

The on-chain scope is tracked in [#13](https://github.com/coreyphillips/ts-tap/issues/13)
and [#19](https://github.com/coreyphillips/ts-tap/issues/19). Issue checkboxes
refer to merged code; a proposed change is not marked as merged evidence.

| Layer | Implementation | Validation |
| --- | --- | --- |
| encoding, asset, address | Codecs, validation, V0/V1/V2 addresses | Pinned Go vectors; URI comparison with Go 1.27.3 |
| mssmt | Full and compacted trees, synchronous in-memory computation | Pinned tree vectors on both implementations |
| commitment, proof | Creation, full verification, STXO/spender and exclusion proofs | Pinned vectors and constructed proof files |
| tapscript, vm | Virtual transactions, BIP 341/342 signing and execution | VM vectors and invalid-witness tests |
| tappsbt | Packet codecs and constructors | Byte-exact pinned vectors |
| tapsend | Allocation, funding, change, passive assets, burns, signing, commitments | V0/V1/V2 sends, splits, merges and proof verification |
| tapchannelmsg | Asset channel records, funding messages and proof chunks, the first part of asset Lightning | Byte-exact vectors printed by Go at the tapd pin, and tapd's v0.8 compatibility blobs |
| rfq | Quote request, accept and reject messages, fixed-point price arithmetic and a session that checks a peer's answer | Byte-exact tapd v0.8 messages and conversions printed by Go at the tapd pin |
| tapchannel | Asset channel commitments, second-level HTLC spends, cooperative close, sweeps, and digests for a host-owned signer | Go vectors for allocations and close layout at the tapd pin; proof files of confirmed commitments, closes and sweeps that verify |
| lightning | HTLC records, a quote book with per-HTLC reservations, quote client and server, asset invoices and the pricing of an incoming asset HTLC, asset channel features, the funding message flow for both sides of a channel open, and the wallet that funds one from its own stores under the lock its sends use | Go vectors for HTLC records at the tapd pin; a channel funded from a mint through both controllers and the funding wallet to confirmed, verified proof files for the channel, the change and a passive asset, with restarts between steps |
| tapgarden | Resumable normal/collectible/group minting and reissuance; group anchor seedlings, caller group internal keys, group tapscript roots, caller script keys and a batch tapscript sibling | Mint stage restarts, the "tapgarden mint options" suite and Beignet examples |
| tapfreighter | Resumable send/receive/burn, import/export, ownership proofs and balances | Stage restarts, reservation races, proof rejection |
| stores | Async batch, asset, proof, parcel, pending anchor, receive and mailbox contracts | Outpoint identity and spent state. `store.runStoreConformance` defines a correct store; `store.keyValueStores` is a durable reference over any atomic key-value backend ([docs/stores.md](docs/stores.md)) |
| couriers | Universe REST and authenticated mailbox, V2 encrypted fragments | Wire-format and ECIES tests. CI runs tapd interop nightly and on pull requests that change `src/`, the adapter, the examples or the regtest stack; V2 receipt needs the patched tapd ([#46](https://github.com/coreyphillips/ts-tap/issues/46)) |
| Beignet | Keys, signers, funding, Electrum | Actual Wallet tests and live regtest workflows |

### Done

Each item names the tests or examples that show it. Quoted names are test
titles; `examples/run.ts` and `examples/interop.cjs` run under
`npm run regtest`.

- Complete on-chain asset lifecycle with public APIs. Signing uses injected
  interfaces; the core library never receives private keys. Shown by
  examples 1 to 6 in [`examples/run.ts`](examples/run.ts) and "no ts-tap
  source signs or handles a private key" in `tests/unit/tapgarden_mint.test.ts`.
- Coin selection, uint64 allocation, multiple recipients and group tranches,
  change, passive carry-over and burns. Signed virtual transactions are
  checked by the VM before anchoring. Shown by "a send to two addresses in
  one anchor transaction", "a passive asset carried over from a spent
  anchor" and "a bad witness is rejected by the VM before anything is
  committed" in `tests/unit/tapsend.test.ts`, "rejects uint64 overflow and
  missing commitments" in `tests/unit/allocation.test.ts`, and "receives an
  unknown group through a V2 address" and "sends, receives, sends change,
  carries passive assets and burns" in `tests/unit/tapfreighter.test.ts`.
- Persistent state-machine records with signed transactions stored before
  broadcast. Resume, or any later call that waits for confirmation, first
  rebroadcasts the identical transaction. Its fee inputs stay reserved until
  it confirms. Shown by "resumes a send persisted at stage" and "rebroadcasts
  a send that left the mempool and holds its fee inputs until it confirms" in
  `tests/unit/tapfreighter.test.ts`, "stops after write" and "rebroadcasts a
  batch that left the mempool" in `tests/unit/tapgarden_mint.test.ts`, and
  example 7.
- A `send` or `burn` that fails before broadcast is cancelled, so `resume`
  cannot pay it a second time. A parcel can be cancelled until it reaches
  the `Broadcast` stage, and a mint batch until its genesis transaction is
  signed. Shown by the "tapfreighter
  cancellation" and "tapgarden batch cancellation" suites.
- Proof import verifies provenance before recording an asset. Proof locators
  include asset ID, script key and anchor outpoint. Shown by "rejects corrupt
  proof imports without storing anything" and "imports unknown ownership as
  watch-only and preserves distinct outpoint proofs" in
  `tests/unit/tapfreighter.test.ts`, and example 6.
- Ownership proofs, as tapd's ProveAssetOwnership and VerifyAssetOwnership:
  `Freighter.proveOwnership` signs a challenge over a held asset without
  moving it, and `proof.verifyOwnership` checks one. Shown by the
  "tapfreighter ownership proofs" suite, and by `examples/interop.cjs`, where
  each side verifies the other's proof.
- Receiving an asset known only by its asset ID or group key:
  `Freighter.lookupAsset` fetches the issuance proof from a universe,
  verifies it against the wallet's chain, and returns the genesis an address
  needs. Shown by the "tapfreighter asset lookup" suite, "receiveIssuanceProof"
  in `tests/unit/courier.test.ts`, and `examples/interop.cjs`, where the
  wallet learns two tapd-minted assets from their IDs before receiving them.
- Universe proof publication and retrieval, authenticated mailbox challenge
  signing, V2 send fragments and XChaCha20-Poly1305 ECIES using an injected
  AEAD. The adapter supplies Beignet's cryptography. Shown by
  `tests/unit/courier.test.ts`, "seals and opens V2 fragments with Beignet
  ECDH and AEAD" in `packages/beignet/tests/adapter.test.ts`, and V1 and V2
  sends in both directions in `examples/interop.cjs`.
- A Beignet workspace adapter that uses its public wallet APIs. Its separate
  hardened TAP key namespace avoids collisions with Lightning keys. Shown by
  "uses a separate hardened namespace and advances persistent counters
  across adapters" in `packages/beignet/tests/adapter.test.ts`.
- Seven runnable Beignet scenarios, an isolated regtest stack and a
  walkthrough describing storage and recovery requirements. Shown by
  `npm run regtest`.

Asset anchors pay to keys on the TAP derivation path, which Beignet's
address scan does not cover. Beignet therefore never lists them, so ordinary
sends cannot spend them, and the bitcoin they hold is missing from the
wallet's BTC balance. `tap.tapLockedSats()` returns that amount for anchors
holding a live asset. It leaves out an anchor holding only a tombstone or a
burn. The adapter also freezes an anchor that does appear in the wallet's
UTXO list, which is rare.

### Boundaries

- `hashmail` addresses still decode for protocol compatibility, but attempts
  to deliver or fetch their proofs fail with a stable error. Configure tapd
  and new addresses with `universerpc` or `authmailbox+universerpc`.
- Receiving to a V2 address does not work through a courier running stock
  tapd, including upstream `main`. Its REST WebSocket proxy ends the mailbox
  request after the first message, so the receiver can never answer the
  authentication challenge. The courier's tapd must carry
  [`tapd-mailbox-websocket.patch`](docker/tapd-mailbox-websocket.patch), as
  the regtest image does. Against stock tapd, receipt fails with
  `ERR_MAILBOX_NOT_BIDIRECTIONAL`. The fix has not been proposed upstream
  yet, and there is no transport that avoids the proxy
  ([#46](https://github.com/coreyphillips/ts-tap/issues/46)).
- Store interfaces are async. A host that must survive process termination
  needs durable stores: use `store.keyValueStores` over an atomic key-value
  backend, or its own stores, and run `store.runStoreConformance` against
  them ([docs/stores.md](docs/stores.md)).
- MS-SMT computation remains synchronous. Trees are reconstructed from stored
  assets and proofs, so there is no hidden database I/O in tree traversal.
- Asset channels, RFQ, channel-only allocations, operating a universe server,
  federation synchronization, `hashmail` delivery and npm publication are
  outside this scope ([#57](https://github.com/coreyphillips/ts-tap/issues/57)).

### Known limitations

These are gaps against tapd, or behaviour a host has to work around, within
the on-chain scope.

- Reorg repair runs only when the host calls `repairProofs()`. A
  transaction that never confirms again after a reorg is not handled.
- No backup or restore API, and a seed alone recovers no assets ([#49](https://github.com/coreyphillips/ts-tap/issues/49)).
- No fee bumping (RBF or CPFP) and no abandon on conflict for a stuck anchor
  transaction ([#48](https://github.com/coreyphillips/ts-tap/issues/48)).
- The query calls (`listTransfers`, `listReceives`, `listAddresses`,
  `listBurns`, `listUtxos`, `listGroups`, `fetchMeta`, `minter.listBatches`)
  filter in memory and do not paginate. A transfer reports its fee rate, not
  the fee paid, which only the wallet knows.
- Minting with an external group key signer (tapd's `FundBatch` and
  `SealBatch`, with group virtual transactions exported for signing) is
  missing. Group witnesses are signed by the injected `AssetSigner` during
  commit. tapd's interop run does not yet cover the other mint options
  ([#52](https://github.com/coreyphillips/ts-tap/issues/52)).
- Advanced transfers missing: interactive sends to script keys, the vPSBT
  flow, script-path keys, mixed asset IDs and burn by group key
  ([#53](https://github.com/coreyphillips/ts-tap/issues/53)).
- No events, logger hook or `AbortSignal` cancellation ([#50](https://github.com/coreyphillips/ts-tap/issues/50)).
- A send or mint whose funded transaction can no longer be signed cannot go
  back to funding ([#31](https://github.com/coreyphillips/ts-tap/issues/31)).
- The default flow lock only excludes coordinators given the same `stores`
  object. Writers that reach one database another way need a host `lock`,
  and the stores do not detect one that bypasses it ([#42](https://github.com/coreyphillips/ts-tap/issues/42)).
- V2 receipt only works through a courier running the patched tapd. See
  [Boundaries](#boundaries) ([#46](https://github.com/coreyphillips/ts-tap/issues/46)).
- The Beignet adapter trusts its Electrum server for the best chain
  ([#61](https://github.com/coreyphillips/ts-tap/issues/61)).

## Test vectors

Every layer is held byte-exact to the BIP test vectors in
lightninglabs/taproot-assets. They are vendored verbatim in
[`tests/testdata`](tests/testdata/README.md), pinned to commit
`0ab6c01c0885b7ffb850efd142b17a1eabe39439`, and a test checks each file's
SHA-256 so an edited vector fails the suite. Each vector file has its own
test under `tests/vectors/`.

## Errors

Codecs and flows throw `TapError`. Branch on its `code`, which is stable, and
not on its message, which is not. `code` is typed as `TapErrorCode`, the union
of every code, so a `switch` over it can be exhaustive. Codes are
`ERR_<AREA>_<NAME>`; [docs/error-codes.md](docs/error-codes.md) lists them all.
A send short of funds throws `ERR_TAPFREIGHTER_INSUFFICIENT_BALANCE`. One whose
assets another unfinished send holds throws
`ERR_TAPFREIGHTER_RESERVATION_CONFLICT`, and may succeed once that send ends.

## Runtime

Runtime dependencies are a subset of beignet's, at beignet's versions, and
none is a native addon. Nothing under `src/` imports a Node built-in module.
`tests/unit/runtime.test.ts` and an eslint rule enforce both.

That makes the core portable, but not free of host requirements. It uses the
global `Buffer`, which React Native does not provide, so a React Native host
must install a polyfill such as the `buffer` package as `global.Buffer`.
Network access, randomness and the cipher are injected: couriers take a
`fetch`, the mailbox takes a `MailboxTransport` (a WebSocket wrapper), and
ECIES takes an `EcdhProvider`, which supplies `randomBytes`, and a
ChaCha20-Poly1305 implementation.
No test runs the library on React Native.

The Beignet adapter's sources import no Node built-in either, and loading it
asks for none that Beignet's own entry point does not already load
(`packages/beignet/tests/runtime.test.ts`). Its V2 mailbox cipher,
`@noble/ciphers`, loads on first use.

## Development

```sh
npm ci
npm run build:all
npm run lint
npm run tsc:check
npm run tsc:check:tests
npm run tsc:check:beignet
npm run tsc:check:examples
npm run coverage
npm run test:beignet
npm run check:uri
```

Only `build:all` builds. The checks that read `dist/` (`tsc:check:beignet`,
`tsc:check:examples`, `test:beignet` and `check:uri`) use whatever it last
produced, so rebuild after changing `src/`. `npm test` runs the TypeScript
sources; `npm run coverage` runs it under c8 and fails below the floor in
`.c8rc.json`. See [CONTRIBUTING.md](CONTRIBUTING.md) for regenerating the
checked-in test data.

`tsc` is TypeScript 7, which has no compiler API. The test loader, the scripts
and typescript-eslint use the TypeScript 6 API from `tools/typescript6`.

Node `^22.23.4 || ^24.22.1 || >=26.12.1`.

### Release tarballs

Neither package is published, so a host outside this workspace vendors
tarballs of both:

```sh
npm run pack:release -- <out-dir>
```

It installs from the lockfile, builds both packages, and writes
`ts-tap-<version>.tgz`, `ts-tap-beignet-<version>.tgz` and a `SHA256SUMS`
file to `<out-dir>`. It refuses a working tree that differs from `HEAD`,
because each build is stamped with its commit: `buildInfo()`, exported by
both packages, returns `{ commit, builtAt }` in a packed build and
`undefined` in any other. Set `SOURCE_DATE_EPOCH` to fix `builtAt`, so the
same commit packs to the same bytes and a checksum can be checked by packing
again.

A tarball carries the compiled files, the declarations and source maps that
name each source file and line, and none of the TypeScript itself: `src/` is
private, and a host may publish what it vendors. A local `npm run build`
still embeds the sources in its maps. `pack:release` builds without them and
refuses a tarball in which a map holds source text or a `.ts` file that is
not a declaration.

Before it reports success it installs both tarballs with Beignet into an
empty CommonJS project and checks that every entry point loads, that
`npm ls` is clean, and that npm resolved one copy of Beignet, `bitcoinjs-lib`
and every other library the packages share with it. `--beignet <version>`
picks the Beignet to install with; the default is the one the adapter is
tested on. The adapter's peer range is `beignet >=0.45.0 <0.46.0`, and it
peers on exactly its own version of `ts-tap`, so vendor the two tarballs
from one run together.

## License

MIT
