# @ts-tap/beignet

Connects a [Beignet](https://github.com/coreyphillips/beignet) wallet to
[ts-tap](https://github.com/coreyphillips/ts-tap): keys, signing, fee
funding, chain access and anchor protection for Taproot Assets.

> **Not ready for mainnet.** Do not use it to hold or move real assets.

`ts-tap` and `beignet` are peer dependencies: the adapter works on the
host's own `Wallet` instance.

```ts
import { createBeignetAdapter } from '@ts-tap/beignet';

const tap = createBeignetAdapter(wallet, { stores, keyIndexes });
```

Pass the same durable `stores` and `keyIndexes` every time the adapter is
rebuilt. The [Beignet walkthrough](https://github.com/coreyphillips/ts-tap/blob/main/docs/beignet.md)
covers persistence, couriers, fees and recovery.

## License

MIT
